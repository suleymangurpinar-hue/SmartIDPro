import 'dart:typed_data';

import '../../compliance/models/face_box.dart';

class OnnxFaceDetectorService {
  static const int inputSize = 640;

  Future<void> init() async {}

  Future<List<FaceBox>> detectFaces(
    Float32List inputTensor, {
    required int imageWidth,
    required int imageHeight,
  }) async {
    print('==============================');
    print('TEST DETECTOR CALLED');
    print('WIDTH : $imageWidth');
    print('HEIGHT: $imageHeight');
    print('==============================');

    return [];
  }

  void dispose() {}
}