import 'dart:math';
import 'package:flutter/material.dart';

class PrintStudioProvider extends ChangeNotifier {
  String _paper = '10x15';
  String _layout = 'Auto';

  double _photoWidthMm = 50;
  double _photoHeightMm = 60;

  String get paper => _paper;
  String get layout => _layout;

  double get photoWidthMm => _photoWidthMm;
  double get photoHeightMm => _photoHeightMm;

  void setPaper(String value) {
    _paper = value;
    notifyListeners();
  }

  void setLayout(String value) {
    _layout = value;
    notifyListeners();
  }

  void setPhotoSize(
    double width,
    double height,
  ) {
    _photoWidthMm = width;
    _photoHeightMm = height;
    notifyListeners();
  }

  void applyPreset({
    required String paperSize,
    required String photoLayout,
  }) {
    _paper = paperSize;
    _layout = photoLayout;
    notifyListeners();
  }

  int get photoCount {
    switch (_layout) {
      case '2':
        return 2;
      case '4':
        return 4;
      case '6':
        return 6;
      case '8':
        return 8;
      case '12':
        return 12;
      case '16':
        return 16;
      default:
        return _autoCount();
    }
  }

  int get crossCount {
    final count = photoCount;

    if (count <= 2) {
      return 2;
    }

    if (count <= 4) {
      return 2;
    }

    if (count <= 6) {
      return 3;
    }

    return 4;
  }

  int get rowCount {
    return (photoCount / crossCount).ceil();
  }

  int _autoCount() {
    const margin = 4.0;
    const gap = 2.0;

    final usableWidth =
        paperWidthMm - (margin * 2);

    final usableHeight =
        paperHeightMm - (margin * 2);

    final horizontal =
        max(
      1,
      ((usableWidth + gap) /
              (photoWidthMm + gap))
          .floor(),
    );

    final vertical =
        max(
      1,
      ((usableHeight + gap) /
              (photoHeightMm + gap))
          .floor(),
    );

    final normal =
        horizontal * vertical;

    final rotatedHorizontal =
        max(
      1,
      ((usableWidth + gap) /
              (photoHeightMm + gap))
          .floor(),
    );

    final rotatedVertical =
        max(
      1,
      ((usableHeight + gap) /
              (photoWidthMm + gap))
          .floor(),
    );

    final rotated =
        rotatedHorizontal *
            rotatedVertical;

    return max(
      normal,
      rotated,
    );
  }

  double get paperWidthMm {
    switch (_paper) {
      case '10x15':
        return 100;
      case '13x18':
        return 130;
      case '15x21':
        return 150;
      case 'A4':
        return 210;
      default:
        return 100;
    }
  }

  double get paperHeightMm {
    switch (_paper) {
      case '10x15':
        return 150;
      case '13x18':
        return 180;
      case '15x21':
        return 210;
      case 'A4':
        return 297;
      default:
        return 150;
    }
  }
}