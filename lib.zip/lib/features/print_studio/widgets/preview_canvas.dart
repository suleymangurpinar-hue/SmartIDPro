import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../enterprise/providers/workspace_provider.dart';
import '../providers/print_studio_provider.dart';

class PreviewCanvas extends StatelessWidget {
  const PreviewCanvas({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final print =
        context.watch<PrintStudioProvider>();

    final workspace =
        context.watch<WorkspaceProvider>();

    final imagePath =
        workspace.imagePath;

    if (imagePath == null) {
      return Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius:
              BorderRadius.circular(14),
        ),
        child: const Center(
          child: Text(
            'Fotoğraf Seçilmedi',
            style: TextStyle(
              color: Colors.black54,
              fontSize: 18,
              fontWeight:
                  FontWeight.w600,
            ),
          ),
        ),
      );
    }

    final count =
        print.photoCount;

    final columns =
        print.crossCount;

    final rows =
        print.rowCount;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(14),
      ),
      child: LayoutBuilder(
        builder: (
          context,
          constraints,
        ) {
          const spacing = 6.0;

          return Padding(
            padding:
                const EdgeInsets.all(
              spacing,
            ),
            child: GridView.builder(
              physics:
                  const NeverScrollableScrollPhysics(),
              itemCount: count,
              gridDelegate:
                  SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount:
                    columns,
                crossAxisSpacing:
                    spacing,
                mainAxisSpacing:
                    spacing,
                childAspectRatio:
                    print.photoWidthMm /
                        print.photoHeightMm,
              ),
              itemBuilder:
                  (
                context,
                index,
              ) {
                return Container(
                  decoration:
                      BoxDecoration(
                    color:
                        Colors.white,
                    border:
                        Border.all(
                      color: Colors
                          .grey
                          .shade300,
                    ),
                  ),
                  child: ClipRect(
                    child: Transform.translate(
                      offset:
                          workspace
                              .offset,
                      child:
                          Transform.scale(
                        scale:
                            workspace
                                .scale,
                        alignment:
                            Alignment
                                .center,
                        child:
                            Image.file(
                          File(
                            imagePath,
                          ),
                          fit: BoxFit
                              .contain,
                          filterQuality:
                              FilterQuality
                                  .high,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}