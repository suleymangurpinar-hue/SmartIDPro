import 'package:flutter/material.dart';
import '../services/document_presets.dart';

class DocumentPresetProvider extends ChangeNotifier {
  DocumentPreset _selected =
      DocumentPresets.turkeyBiometric;

  DocumentPreset get selected => _selected;

  String get paperSize {
    switch (_selected.name) {
      case 'Turkey Biometric':
        return '10x15';
      case 'Schengen Visa':
        return '10x15';
      case 'USA Visa':
        return '10x15';
      default:
        return '10x15';
    }
  }

  int get autoLayout {
    switch (_selected.name) {
      case 'Turkey Biometric':
        return 4;

      case 'Schengen Visa':
        return 8;

      case 'USA Visa':
        return 6;

      case 'UK Visa':
        return 8;

      case 'Canada Visa':
        return 4;

      default:
        return 8;
    }
  }

  void changePreset(
    DocumentPreset preset,
  ) {
    _selected = preset;
    notifyListeners();
  }
}