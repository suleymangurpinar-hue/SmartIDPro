import 'package:flutter/material.dart';

class WorkspaceProvider extends ChangeNotifier {
  String? _imagePath;

  double _scale = 1.0;
  Offset _offset = Offset.zero;

  double _headRatio = 0.75;

  String? get imagePath => _imagePath;
  double get scale => _scale;
  Offset get offset => _offset;
  double get headRatio => _headRatio;

  void setImage(String path) {
    _imagePath = path;

    _scale = 1.0;
    _offset = Offset.zero;
    _headRatio = 0.75;

    notifyListeners();
  }

  void applyAutoCropPreset({
    required double headRatio,
  }) {
    _headRatio = headRatio;

    if (_imagePath == null) {
      notifyListeners();
      return;
    }

    if (headRatio >= 0.78) {
      _scale = 1.18;
      _offset = const Offset(0, -50);
    } else if (headRatio >= 0.74) {
      _scale = 1.08;
      _offset = const Offset(0, -35);
    } else if (headRatio >= 0.70) {
      _scale = 1.0;
      _offset = const Offset(0, -25);
    } else {
      _scale = 0.92;
      _offset = const Offset(0, -15);
    }

    notifyListeners();
  }

  void applyAutoCrop({
    required double scale,
    required Offset offset,
  }) {
    _scale = scale;
    _offset = offset;
    notifyListeners();
  }

  void resetCrop() {
    _scale = 1.0;
    _offset = Offset.zero;
    _headRatio = 0.75;

    notifyListeners();
  }

  void clear() {
    _imagePath = null;
    _scale = 1.0;
    _offset = Offset.zero;
    _headRatio = 0.75;

    notifyListeners();
  }
}