class DocumentPreset {
  final String name;
  final String country;

  final double widthMm;
  final double heightMm;

  final double headMinPercent;
  final double headMaxPercent;

  final double eyeMinMm;
  final double eyeMaxMm;

  final String paper;
  final int layout;
  final int dpi;

  const DocumentPreset({
    required this.name,
    required this.country,
    required this.widthMm,
    required this.heightMm,
    required this.headMinPercent,
    required this.headMaxPercent,
    required this.eyeMinMm,
    required this.eyeMaxMm,
    required this.paper,
    required this.layout,
    required this.dpi,
  });
}

class DocumentPresets {
  static const turkeyBiometric = DocumentPreset(
    name: 'Türkiye Biyometrik',
    country: 'TR',
    widthMm: 50,
    heightMm: 60,
    headMinPercent: 70,
    headMaxPercent: 80,
    eyeMinMm: 28,
    eyeMaxMm: 35,
    paper: '10x15',
    layout: 4,
    dpi: 300,
  );

  static const turkeyPassport = DocumentPreset(
    name: 'Türkiye Vesikalık',
    country: 'TR',
    widthMm: 35,
    heightMm: 45,
    headMinPercent: 70,
    headMaxPercent: 80,
    eyeMinMm: 28,
    eyeMaxMm: 35,
    paper: '10x15',
    layout: 8,
    dpi: 300,
  );

  static const schengenVisa = DocumentPreset(
    name: 'Schengen Vize',
    country: 'EU',
    widthMm: 35,
    heightMm: 45,
    headMinPercent: 70,
    headMaxPercent: 80,
    eyeMinMm: 28,
    eyeMaxMm: 35,
    paper: '10x15',
    layout: 8,
    dpi: 300,
  );

  static const usaVisa = DocumentPreset(
    name: 'ABD Vize',
    country: 'USA',
    widthMm: 51,
    heightMm: 51,
    headMinPercent: 68,
    headMaxPercent: 78,
    eyeMinMm: 28,
    eyeMaxMm: 35,
    paper: '10x15',
    layout: 4,
    dpi: 300,
  );

  static const all = [
    turkeyBiometric,
    turkeyPassport,
    schengenVisa,
    usaVisa,
  ];
}