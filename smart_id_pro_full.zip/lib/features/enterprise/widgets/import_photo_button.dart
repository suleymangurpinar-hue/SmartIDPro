import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../l10n/app_localizations.dart';

import '../../compliance/services/face_detector_service.dart';

import '../providers/workspace_provider.dart';
import '../providers/process_queue_provider.dart';

import '../services/photo_import_service.dart';
import '../services/file_name_service.dart';

class ImportPhotoButton extends StatelessWidget {
  const ImportPhotoButton({super.key});

  Future<void> _autoCrop(BuildContext context, String imagePath) async {
    final face = await FaceDetectorService().detectFace(imagePath);

    if (!face.faceFound) {
      return;
    }

    final targetHead = 0.74;

    final scale = targetHead / face.height;

    final dx = (0.5 - (face.x + face.width / 2)) * 600;

    final dy = (0.32 - face.y) * 700;

    if (!context.mounted) {
      return;
    }

    context.read<WorkspaceProvider>().applyAutoCrop(
      scale: scale,
      offset: Offset(dx, dy),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return ElevatedButton.icon(
      onPressed: () async {
        final path = await PhotoImportService.pickPhoto();

        if (path == null) {
          return;
        }

        if (!context.mounted) {
          return;
        }

        context.read<WorkspaceProvider>().setImage(path);

        await _autoCrop(context, path);

        if (!context.mounted) {
          return;
        }

        context.read<ProcessQueueProvider>().add(FileNameService.extract(path));
      },
      icon: const Icon(Icons.add_photo_alternate),
      label: Text(l10n.importPhoto),
    );
  }
}
