class PhotoLayout {
  final String name;
  final int count;

  const PhotoLayout({
    required this.name,
    required this.count,
  });

  static const presets = [
    PhotoLayout(name: 'Auto', count: 0),
    PhotoLayout(name: '4', count: 4),
    PhotoLayout(name: '6', count: 6),
    PhotoLayout(name: '8', count: 8),
    PhotoLayout(name: '12', count: 12),
  ];
}