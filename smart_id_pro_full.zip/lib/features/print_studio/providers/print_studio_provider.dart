import 'package:flutter/material.dart';

class PrintStudioProvider
    extends ChangeNotifier {
  String paper = '10x15';

  String layout = '4';

  int quantity = 1;

  void applyPreset({
    required String paperSize,
    required int photoLayout,
  }) {
    paper = paperSize;
    layout = photoLayout.toString();
    notifyListeners();
  }

  void setPaper(String value) {
    paper = value;
    notifyListeners();
  }

  void setLayout(String value) {
    layout = value;
    notifyListeners();
  }

  void setQuantity(int value) {
    quantity = value;
    notifyListeners();
  }

  int get photoCount {
    return int.tryParse(layout) ?? 8;
  }

  int get crossCount {
    if (photoCount <= 4) {
      return 2;
    }

    if (photoCount <= 8) {
      return 4;
    }

    return 4;
  }
}