class AutoLayoutService {
  static int calculate(
    String documentType,
    String paper,
  ) {
    switch (documentType) {
      case 'Turkey Biometric':
        return 4;

      case 'Schengen Visa':
        return 8;

      case 'USA Visa':
        return 6;

      case 'UK Visa':
        return 8;

      case 'Canada Visa':
        return 4;

      default:
        return 8;
    }
  }
}