import 'package:flutter/material.dart';
import '../services/print_preview_service.dart';

class PreviewCanvas extends StatelessWidget {
  final int count;

  const PreviewCanvas({super.key, required this.count});

  @override
  Widget build(BuildContext context) {
    final cross = PrintPreviewService.calculateCrossCount(count);

    return AspectRatio(
      aspectRatio: 1.5,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
        ),
        child: GridView.count(
          physics: const NeverScrollableScrollPhysics(),
          padding: const EdgeInsets.all(12),
          crossAxisCount: cross,
          crossAxisSpacing: 6,
          mainAxisSpacing: 6,
          children: List.generate(
            count,
            (_) => Container(
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(6),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
